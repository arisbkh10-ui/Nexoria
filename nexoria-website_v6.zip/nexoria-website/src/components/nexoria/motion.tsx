import { motion, useReducedMotion, useScroll, useTransform, type Variants } from "framer-motion";
import { useRef, type ReactNode } from "react";

/** One easing curve for the whole site: quick start, long soft landing. */
export const ease = [0.22, 1, 0.36, 1] as const;

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0, transition: { duration: 0.9, ease } },
};

/** Fade-and-rise when the element scrolls into view (once). */
export function Reveal({
  children,
  className,
  delay = 0,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "li" | "p" | "figure";
}) {
  const M = motion[as];
  return (
    <M
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "0px 0px -12% 0px" }}
      variants={fadeUp}
      transition={{ delay }}
    >
      {children}
    </M>
  );
}

const lineParent: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.085 } },
};
const lineChild: Variants = {
  hidden: { y: "108%" },
  show: { y: "0%", transition: { duration: 1.05, ease } },
};

/**
 * Headline whose lines rise out of a mask, one after another.
 * Pass each visual line as an item so the break points stay art-directed.
 */
export function Lines({
  lines,
  className,
  as = "h2",
  onMount = false,
  delay = 0,
  lineClassName,
}: {
  lines: ReactNode[];
  className?: string;
  as?: "h1" | "h2" | "h3" | "p";
  onMount?: boolean;
  delay?: number;
  lineClassName?: (i: number) => string | undefined;
}) {
  const M = motion[as];
  const trigger = onMount
    ? { animate: "show" as const }
    : { whileInView: "show" as const, viewport: { once: true, margin: "0px 0px -10% 0px" } };
  return (
    <M
      className={className}
      initial="hidden"
      {...trigger}
      variants={lineParent}
      transition={{ delayChildren: delay }}
    >
      {lines.map((l, i) => (
        <span
          key={i}
          className={`block overflow-hidden pb-[0.08em] -mb-[0.08em] ${lineClassName?.(i) ?? ""}`}
        >
          <motion.span className="block will-change-transform" variants={lineChild}>
            {l}
          </motion.span>
        </span>
      ))}
    </M>
  );
}

/**
 * Image that unveils from the bottom edge and settles from a slight scale.
 * Optional parallax drift tied to scroll. Both are skipped with reduced motion.
 */
export function RevealImage({
  src,
  alt,
  width,
  height,
  className = "",
  imgClassName = "",
  parallax = 0,
  priority = false,
  onMount = false,
  delay = 0,
  sizes,
}: {
  src: string;
  alt: string;
  width: number;
  height: number;
  className?: string;
  imgClassName?: string;
  parallax?: number;
  priority?: boolean;
  onMount?: boolean;
  delay?: number;
  sizes?: string;
}) {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  // Same animated properties in every mode so server-rendered styles are always
  // overwritten on the client; reduced motion only changes the timing.
  const amount = reduce ? 0 : parallax;
  const y = useTransform(scrollYProgress, [0, 1], [`${-amount}%`, `${amount}%`]);

  const hidden = { clipPath: "inset(100% 0% 0% 0%)", opacity: 0 };
  const shown = {
    clipPath: "inset(0% 0% 0% 0%)",
    opacity: 1,
    transition: reduce
      ? { clipPath: { duration: 0 }, opacity: { duration: 0.6, delay } }
      : { clipPath: { duration: 1.25, ease, delay }, opacity: { duration: 0.3, delay } },
  };
  const trigger = onMount
    ? { animate: shown }
    : { whileInView: shown, viewport: { once: true, margin: "0px 0px -8% 0px" } };

  return (
    <motion.div
      ref={ref}
      className={`relative overflow-hidden ${className}`}
      initial={hidden}
      {...trigger}
    >
      <motion.div className="h-full w-full" style={{ y, scale: 1 + amount / 50 }}>
        <motion.img
          src={src}
          alt={alt}
          width={width}
          height={height}
          sizes={sizes}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          fetchPriority={priority ? "high" : undefined}
          className={`h-full w-full object-cover ${imgClassName}`}
          initial={{ scale: reduce ? 1 : 1.08 }}
          {...(onMount
            ? { animate: { scale: 1 } }
            : { whileInView: { scale: 1 }, viewport: { once: true } })}
          transition={{ duration: 1.6, ease, delay }}
        />
      </motion.div>
    </motion.div>
  );
}

/** Text whose words brighten as the reader scrolls through it. */
export function ScrollWords({ text, className }: { text: string; className?: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 85%", "end 45%"] });
  const words = text.split(" ");
  return (
    <p ref={ref} className={className}>
      {words.map((w, i) => (
        <Word
          key={i}
          progress={scrollYProgress}
          range={[i / words.length, (i + 1) / words.length]}
          still={!!reduce}
        >
          {w}
        </Word>
      ))}
    </p>
  );
}

function Word({
  children,
  progress,
  range,
  still,
}: {
  children: string;
  progress: ReturnType<typeof useScroll>["scrollYProgress"];
  range: [number, number];
  still: boolean;
}) {
  const opacity = useTransform(progress, range, still ? [1, 1] : [0.18, 1]);
  return (
    <>
      <motion.span style={{ opacity }}>{children}</motion.span>{" "}
    </>
  );
}

/** Arrow that slides out and comes back in on hover of the closest `.group`. */
export function SlideArrow({
  className = "h-4 w-4",
  diagonal = false,
}: {
  className?: string;
  diagonal?: boolean;
}) {
  const path = diagonal ? "M7 17 17 7M8 7h9v9" : "M5 12h14M13 6l6 6-6 6";
  const out = diagonal
    ? "group-hover:translate-x-[120%] group-hover:-translate-y-[120%]"
    : "group-hover:translate-x-[130%]";
  const inn = diagonal
    ? "-translate-x-[120%] translate-y-[120%] group-hover:translate-x-0 group-hover:translate-y-0"
    : "-translate-x-[130%] group-hover:translate-x-0";
  const svg = (cls: string) => (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`absolute inset-0 h-full w-full transition-transform duration-500 ease-[var(--ease-studio)] ${cls}`}
      aria-hidden
    >
      <path d={path} />
    </svg>
  );
  return (
    <span className={`relative inline-block shrink-0 overflow-hidden ${className}`} aria-hidden>
      {svg(out)}
      {svg(inn)}
    </span>
  );
}
