import { createFileRoute } from "@tanstack/react-router";
import {
  AnimatePresence,
  motion,
  MotionConfig,
  useInView,
  useReducedMotion,
  useScroll,
  useSpring,
} from "framer-motion";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import heroImg from "@/assets/hero-arcade.webp";
import studioImg from "@/assets/studio.webp";
import codeImg from "@/assets/service-code.webp";
import productImg from "@/assets/service-product.webp";
import restaurantImg from "@/assets/project-restaurant.webp";
import fashionImg from "@/assets/project-fashion.webp";
import realestateImg from "@/assets/project-realestate.webp";
import bejaiaImg from "@/assets/about-bejaia.webp";
import lightImg from "@/assets/contact-light.webp";
import {
  ease,
  Lines,
  Reveal,
  RevealImage,
  ScrollWords,
  SlideArrow,
} from "@/components/nexoria/motion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NEXORIA — Beautiful websites, built to be found" },
      {
        name: "description",
        content:
          "NEXORIA designs fast, SEO-friendly websites that help businesses in Béjaïa, across Algeria and beyond get found on Google and win new customers.",
      },
      { property: "og:title", content: "NEXORIA — Beautiful websites, built to be found" },
      {
        property: "og:description",
        content:
          "Web design, development, e-commerce and SEO from an independent studio in Béjaïa, Algeria.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const wrap = "mx-auto w-full max-w-[1440px] px-5 sm:px-8 lg:px-12";
const EMAIL = "nexoriaalgeria@gmail.com";

/* ------------------------------------------------------------------ */
/* Small shared pieces                                                 */
/* ------------------------------------------------------------------ */

/** Local time at the studio (Béjaïa uses the Africa/Algiers time zone). */
function useStudioTime() {
  const [t, setT] = useState<string | null>(null);
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("fr-FR", {
      timeZone: "Africa/Algiers",
      hour: "2-digit",
      minute: "2-digit",
    });
    const tick = () => setT(fmt.format(new Date()));
    tick();
    const id = window.setInterval(tick, 20_000);
    return () => window.clearInterval(id);
  }, []);
  return t;
}

function Logo({ onDark = false }: { onDark?: boolean }) {
  return (
    <a href="#home" className="group flex items-center gap-2.5" aria-label="NEXORIA — back to top">
      <svg width="22" height="22" viewBox="0 0 26 26" fill="none" aria-hidden>
        <rect x="1" y="1" width="24" height="24" rx="2" stroke="currentColor" strokeWidth="1.5" />
        <rect
          x="13"
          y="13"
          width="9"
          height="9"
          rx="1"
          className="fill-primary transition-transform duration-700 ease-[var(--ease-studio)] group-hover:-translate-x-[9px] group-hover:-translate-y-[9px]"
        />
      </svg>
      <span
        className={`font-heading text-[17px] font-semibold tracking-[0.14em] ${onDark ? "text-ink-foreground" : ""}`}
      >
        NEXORIA
      </span>
    </a>
  );
}

function Button({
  href,
  children,
  variant = "primary",
  className = "",
  onClick,
  type,
}: {
  href?: string;
  children: ReactNode;
  variant?: "primary" | "light";
  className?: string;
  onClick?: () => void;
  type?: "submit" | "button";
}) {
  const base =
    "group relative inline-flex h-12 items-center gap-3 overflow-hidden pl-6 pr-5 font-heading text-[14.5px] font-semibold tracking-[-0.005em] transition-colors duration-500";
  const tone =
    variant === "primary" ? "bg-primary text-primary-foreground" : "bg-ink-foreground text-ink";
  const fill = variant === "primary" ? "bg-foreground" : "bg-primary";
  const inner = (
    <>
      <span
        className={`absolute inset-0 translate-y-full ${fill} transition-transform duration-500 ease-[var(--ease-studio)] group-hover:translate-y-0`}
        aria-hidden
      />
      <span
        className={`relative z-10 ${variant === "light" ? "transition-colors duration-500 group-hover:text-primary-foreground" : ""}`}
      >
        {children}
      </span>
      <SlideArrow
        className={`relative z-10 h-4 w-4 ${variant === "light" ? "transition-colors duration-500 group-hover:text-primary-foreground" : ""}`}
      />
    </>
  );
  if (href)
    return (
      <a href={href} className={`${base} ${tone} ${className}`}>
        {inner}
      </a>
    );
  return (
    <button type={type ?? "button"} onClick={onClick} className={`${base} ${tone} ${className}`}>
      {inner}
    </button>
  );
}

function TextLink({
  href,
  children,
  className = "",
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <a
      href={href}
      className={`group inline-flex items-center gap-2 font-heading text-[14.5px] font-semibold ${className}`}
    >
      <span className="link-undraw pb-0.5">{children}</span>
      <SlideArrow className="h-3.5 w-3.5" diagonal />
    </a>
  );
}

function Kicker({
  n,
  children,
  className = "",
  onDark = false,
}: {
  n: string;
  children: ReactNode;
  className?: string;
  onDark?: boolean;
}) {
  return (
    <p
      className={`eyebrow flex items-center gap-3 ${onDark ? "text-ink-muted" : "text-muted-foreground"} ${className}`}
    >
      <span className="text-primary">({n})</span>
      <span>{children}</span>
    </p>
  );
}

/* ------------------------------------------------------------------ */
/* Navigation                                                          */
/* ------------------------------------------------------------------ */

const navItems = [
  { label: "Services", href: "#services" },
  { label: "SEO", href: "#seo" },
  { label: "Work", href: "#work" },
  { label: "Process", href: "#process" },
  { label: "About", href: "#about" },
];

function useActiveSection(ids: string[]) {
  const [active, setActive] = useState<string | null>(null);
  useEffect(() => {
    const els = ids.map((id) => document.getElementById(id)).filter((e): e is HTMLElement => !!e);
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [ids]);
  return active;
}

const sectionIds = navItems.map((n) => n.href.slice(1)).concat("contact");

function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [open, setOpen] = useState(false);
  const active = useActiveSection(sectionIds);
  const time = useStudioTime();
  const firstLink = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    let last = window.scrollY;
    const on = () => {
      const y = window.scrollY;
      setScrolled(y > 24);
      setHidden(y > last && y > 640);
      last = y;
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    firstLink.current?.focus();
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-[transform,background-color,border-color] duration-500 ease-[var(--ease-studio)] ${
          hidden && !open ? "-translate-y-full" : "translate-y-0"
        } ${scrolled && !open ? "border-b border-border bg-background/85 backdrop-blur-md" : "border-b border-transparent"}`}
      >
        <div className={`${wrap} flex h-[68px] items-center justify-between gap-6`}>
          <Logo />
          <nav aria-label="Main" className="hidden items-center gap-8 lg:flex">
            {navItems.map((n, i) => {
              const isActive = active === n.href.slice(1);
              return (
                <a
                  key={n.href}
                  href={n.href}
                  aria-current={isActive ? "true" : undefined}
                  className={`group relative flex items-baseline gap-1.5 py-2 font-heading text-[14px] font-medium transition-colors duration-300 ${
                    isActive ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <span className="text-[10px] tabular-nums text-primary/80">0{i + 1}</span>
                  {n.label}
                  <span
                    className={`absolute inset-x-0 -bottom-px h-px origin-left bg-foreground transition-transform duration-500 ease-[var(--ease-studio)] ${
                      isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                    }`}
                    aria-hidden
                  />
                </a>
              );
            })}
          </nav>
          <div className="flex items-center gap-6">
            <p
              className="eyebrow hidden text-muted-foreground xl:block"
              aria-label="Local time in Béjaïa"
            >
              Béjaïa&nbsp;<span className="tabular-nums text-foreground">{time ?? "--:--"}</span>
            </p>
            <a
              href="#contact"
              className="group hidden h-10 items-center gap-2.5 border border-foreground/80 px-4 font-heading text-[13.5px] font-semibold transition-colors duration-300 hover:bg-foreground hover:text-background md:inline-flex"
            >
              Start a project <SlideArrow className="h-3.5 w-3.5" diagonal />
            </a>
            <button
              className="relative -mr-2 flex h-11 w-11 items-center justify-center lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((o) => !o)}
            >
              <span
                className={`absolute h-px w-6 bg-foreground transition-transform duration-500 ease-[var(--ease-studio)] ${open ? "rotate-45" : "-translate-y-[4px]"}`}
              />
              <span
                className={`absolute h-px w-6 bg-foreground transition-transform duration-500 ease-[var(--ease-studio)] ${open ? "-rotate-45" : "translate-y-[4px]"}`}
              />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            className="fixed inset-0 z-40 flex flex-col bg-background pt-[68px] lg:hidden"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.7, ease }}
          >
            <nav aria-label="Mobile" className={`${wrap} flex flex-1 flex-col justify-center`}>
              {[...navItems, { label: "Contact", href: "#contact" }].map((n, i) => (
                <motion.a
                  key={n.href}
                  ref={i === 0 ? firstLink : undefined}
                  href={n.href}
                  onClick={() => setOpen(false)}
                  className="flex items-baseline gap-4 border-b border-border py-4 font-heading text-[2.4rem] font-medium leading-none tracking-[-0.03em]"
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, transition: { duration: 0.2 } }}
                  transition={{ duration: 0.7, ease, delay: 0.15 + i * 0.05 }}
                >
                  <span className="eyebrow text-primary">0{i + 1}</span>
                  {n.label}
                </motion.a>
              ))}
            </nav>
            <motion.div
              className={`${wrap} flex flex-wrap items-end justify-between gap-x-6 gap-y-2 pb-8`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1, transition: { delay: 0.5 } }}
              exit={{ opacity: 0 }}
            >
              <a href={`mailto:${EMAIL}`} className="text-[15px] font-medium">
                {EMAIL}
              </a>
              <p className="eyebrow text-muted-foreground">Béjaïa {time ?? ""}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */

const heroPoints = ["Custom design", "Mobile-first", "SEO foundations", "Fast loading"];

function Hero() {
  const time = useStudioTime();
  const fade = (delay: number) => ({
    initial: { opacity: 0, y: 14 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.9, ease, delay },
  });
  return (
    <section id="home" className="relative pt-[100px] md:pt-[120px]">
      <div className={wrap}>
        <motion.div
          {...fade(0.05)}
          className="eyebrow grid grid-cols-2 gap-4 border-b border-border pb-4 text-muted-foreground md:grid-cols-3 lg:grid-cols-4"
        >
          <p>Studio web — Béjaïa</p>
          <p className="hidden lg:block">Design · Development · SEO</p>
          <p className="hidden items-center gap-2 md:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden /> Available for new
            projects
          </p>
          <p className="text-right tabular-nums">
            {time ?? "--:--"} <span className="text-muted-foreground/70">GMT+1</span>
          </p>
        </motion.div>

        <Lines
          as="h1"
          onMount
          delay={0.15}
          className="display-xl mt-10 md:mt-16"
          lineClassName={(i) => (i === 1 ? "sm:pl-[12%] lg:pl-[16.66%]" : undefined)}
          lines={[
            "Beautiful websites,",
            <>
              built to be found<span className="text-primary">.</span>
            </>,
          ]}
        />

        <div className="mt-10 grid gap-10 md:mt-16 md:grid-cols-12 md:items-end">
          <motion.ol
            {...fade(0.55)}
            className="order-2 grid grid-cols-2 gap-x-6 md:order-1 md:col-span-5 lg:col-span-4"
          >
            {heroPoints.map((t, i) => (
              <li
                key={t}
                className="flex items-baseline gap-3 border-t border-border py-3 text-[14.5px]"
              >
                <span className="eyebrow text-primary">0{i + 1}</span>
                {t}
              </li>
            ))}
          </motion.ol>
          <motion.div
            {...fade(0.45)}
            className="order-1 md:order-2 md:col-span-7 md:col-start-6 lg:col-span-5 lg:col-start-8"
          >
            <p className="lede text-muted-foreground">
              We design and build fast, modern websites that give your business a credible presence,
              attract new customers and are made to compete on Google.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4">
              <Button href="#contact">Start your project</Button>
              <TextLink href="#work">See our work</TextLink>
            </div>
          </motion.div>
        </div>
      </div>

      <div className={`${wrap} mt-14 md:mt-20`}>
        <RevealImage
          src={heroImg}
          alt="Sunlight falling through a stone arcade, casting long geometric shadows"
          width={1600}
          height={1067}
          onMount
          priority
          delay={0.3}
          parallax={6}
          sizes="(min-width: 1440px) 1344px, 100vw"
          className="aspect-[4/5] sm:aspect-[16/10] lg:aspect-[2.35/1]"
        />
        <motion.div
          {...fade(1)}
          className="eyebrow mt-4 grid grid-cols-12 gap-4 pb-24 text-muted-foreground md:pb-32"
        >
          <p className="col-span-3 md:col-span-2">Fig. 01</p>
          <p className="col-span-9 normal-case tracking-normal text-[13px] md:col-span-6">
            Light, structure, a clear way through — the principles behind every site we build.
          </p>
          <a
            href="#services"
            className="group hidden items-center justify-end gap-2 md:col-span-4 md:flex"
          >
            <span className="link-draw">Scroll</span>
            <svg
              viewBox="0 0 24 24"
              className="h-3.5 w-3.5 transition-transform duration-500 group-hover:translate-y-0.5"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              aria-hidden
            >
              <path d="M12 5v14M6 13l6 6 6-6" />
            </svg>
          </a>
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Services — editorial index with a sticky preview                    */
/* ------------------------------------------------------------------ */

type Service = {
  t: string;
  d: string;
  tags: string[];
  img?: string;
  w?: number;
  h?: number;
  alt?: string;
  caption: string;
  href?: string;
};

const services: Service[] = [
  {
    t: "Web Design",
    d: "Art-directed interfaces shaped around your brand and your customers — clear, elegant and built to convert.",
    tags: ["Art direction", "UI / UX", "Responsive layouts"],
    img: studioImg,
    w: 1408,
    h: 1008,
    alt: "Hand sketching website wireframes on paper beside a laptop",
    caption: "Every layout starts on paper.",
  },
  {
    t: "Development",
    d: "Fast, reliable and responsive websites built with modern technology and clean, semantic code.",
    tags: ["Semantic code", "Performance", "Accessibility"],
    img: codeImg,
    w: 1400,
    h: 822,
    alt: "HTML markup displayed on a monitor in a dim room",
    caption: "Clean markup, fast pages.",
  },
  {
    t: "E-commerce",
    d: "Online stores that showcase your products beautifully and make buying simple on every device.",
    tags: ["Product pages", "Simple checkout", "Mobile-first"],
    img: productImg,
    w: 1400,
    h: 934,
    alt: "Terracotta and cream ceramic vases arranged as a product still life",
    caption: "Products, presented with care.",
  },
  {
    t: "SEO & Google Visibility",
    d: "From technical SEO and website performance to mobile optimization and structured content, we build websites with search engine visibility in mind.",
    tags: ["Technical SEO", "Metadata", "Indexing"],
    caption: "Built to be found.",
    href: "#seo",
  },
];

function SeoPanel() {
  return (
    <div className="flex h-full w-full flex-col justify-between bg-ink p-8 text-ink-foreground md:p-10">
      <p className="eyebrow text-ink-muted">Search results — position</p>
      <p className="font-heading text-[clamp(7rem,16vw,15rem)] font-medium leading-[0.8] tracking-[-0.05em]">
        01<span className="text-primary-soft">.</span>
      </p>
      <div className="space-y-3">
        {[100, 72, 58].map((w, i) => (
          <div key={i} className="flex items-center gap-3">
            <span className={`h-2 w-2 ${i === 0 ? "bg-primary-soft" : "bg-ink-border"}`} />
            <span
              className={`h-px ${i === 0 ? "bg-ink-foreground" : "bg-ink-border"}`}
              style={{ width: `${w}%` }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function Services() {
  const [active, setActive] = useState(0);
  const rows = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(Number((e.target as HTMLElement).dataset["index"]));
        });
      },
      { rootMargin: "-48% 0px -48% 0px" },
    );
    rows.current.forEach((r) => r && io.observe(r));
    return () => io.disconnect();
  }, []);

  return (
    <section id="services" className="border-t border-border py-24 md:py-36">
      <div className={wrap}>
        <div className="grid gap-8 md:grid-cols-12">
          <Reveal className="md:col-span-4 lg:col-span-3">
            <Kicker n="01">Services</Kicker>
          </Reveal>
          <div className="md:col-span-8 lg:col-span-9">
            <Lines
              className="display"
              lines={["Everything your business", "needs to grow online."]}
            />
            <Reveal delay={0.1}>
              <p className="lede mt-6 max-w-[46ch] text-muted-foreground">
                Design, development, e-commerce and SEO work together — one team, one coherent
                result.
              </p>
            </Reveal>
          </div>
        </div>

        <div className="mt-16 grid gap-12 md:mt-24 lg:grid-cols-12">
          {/* Sticky preview (desktop) */}
          <div className="hidden lg:col-span-5 lg:block">
            <div className="sticky top-24">
              <Reveal className="relative aspect-[4/5] overflow-hidden bg-card">
                {services.map((s, i) => (
                  <div
                    key={s.t}
                    className={`absolute inset-0 transition-[opacity,transform] duration-[900ms] ease-[var(--ease-studio)] ${
                      active === i ? "scale-100 opacity-100" : "scale-[1.03] opacity-0"
                    }`}
                    aria-hidden={active !== i}
                  >
                    {s.img ? (
                      <img
                        src={s.img}
                        alt={s.alt}
                        width={s.w}
                        height={s.h}
                        loading="lazy"
                        decoding="async"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <SeoPanel />
                    )}
                  </div>
                ))}
              </Reveal>
              <div className="eyebrow mt-4 flex justify-between text-muted-foreground">
                <span>Fig. 0{active + 2}</span>
                <span className="normal-case tracking-normal text-[13px]">
                  {services[active]?.caption}
                </span>
              </div>
            </div>
          </div>

          {/* Index */}
          <ol className="border-b border-border lg:col-span-7">
            {services.map((s, i) => {
              const on = active === i;
              const Wrapper = s.href ? "a" : "div";
              return (
                <li
                  key={s.t}
                  ref={(el) => {
                    rows.current[i] = el;
                  }}
                  data-index={i}
                  onMouseEnter={() => setActive(i)}
                  className="border-t border-border"
                >
                  <Reveal>
                    <Wrapper
                      {...(s.href ? { href: s.href } : {})}
                      className="group grid grid-cols-[3rem_1fr] gap-x-4 py-9 md:grid-cols-[4.5rem_1fr_auto] md:py-12"
                    >
                      <span
                        className={`eyebrow pt-2 transition-colors duration-500 ${on ? "text-primary" : "text-muted-foreground"}`}
                      >
                        0{i + 1}
                      </span>
                      <div>
                        <h3
                          className={`font-heading text-[clamp(1.85rem,3.4vw,3.1rem)] font-medium leading-[1.06] tracking-[-0.03em] transition-colors duration-500 ${
                            on ? "text-foreground" : "lg:text-foreground/30"
                          }`}
                        >
                          {s.t}
                        </h3>
                        {s.img && (
                          <div className="mt-6 aspect-[16/10] overflow-hidden lg:hidden">
                            <img
                              src={s.img}
                              alt={s.alt}
                              width={s.w}
                              height={s.h}
                              loading="lazy"
                              decoding="async"
                              className="h-full w-full object-cover"
                            />
                          </div>
                        )}
                        <p className="mt-5 max-w-[48ch] text-muted-foreground">{s.d}</p>
                        <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
                          {s.tags.map((t) => (
                            <li key={t} className="eyebrow text-foreground/70">
                              {t}
                            </li>
                          ))}
                        </ul>
                      </div>
                      {s.href && (
                        <span className="col-start-2 mt-6 flex items-center gap-2 text-[14px] font-medium text-primary md:col-start-3 md:mt-2 md:self-start">
                          <span className="hidden md:inline">See how</span>
                          <SlideArrow className="h-5 w-5" diagonal />
                        </span>
                      )}
                    </Wrapper>
                  </Reveal>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* SEO                                                                 */
/* ------------------------------------------------------------------ */

const seoPoints = [
  "Technical SEO foundations",
  "Fast loading performance",
  "Mobile-first design",
  "Semantic HTML structure",
  "Optimized metadata",
  "Search-friendly content structure",
  "Image optimization",
  "Google indexing readiness",
];

type Result = { id: string; crumb: string; title: string; text: string; you?: boolean };
const results: Record<string, Result> = {
  a: {
    id: "a",
    crumb: "City guide › bejaia › dining",
    title: "Where to eat in Béjaïa — restaurant guide",
    text: "A selection of addresses across the city, with opening hours and neighbourhood maps…",
  },
  b: {
    id: "b",
    crumb: "Listings › restaurants › bejaia",
    title: "Restaurants in Béjaïa — directory and reviews",
    text: "Browse restaurants by district, cuisine and price. Phone numbers and directions…",
  },
  you: {
    id: "you",
    you: true,
    crumb: "yourbusiness.dz › menu",
    title: "Your Restaurant — Seasonal cuisine in Béjaïa",
    text: "Discover our menu, opening hours and book your table online in a few clicks…",
  },
};

function SerpMock() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -25% 0px" });
  const reduce = useReducedMotion();
  const [ranked, setRanked] = useState(false);
  useEffect(() => {
    if (!inView) return;
    if (reduce) return setRanked(true);
    const id = window.setTimeout(() => setRanked(true), 900);
    return () => window.clearTimeout(id);
  }, [inView, reduce]);
  const order = ranked ? ["you", "a", "b"] : ["a", "b", "you"];

  return (
    <div
      ref={ref}
      className="bg-background text-foreground shadow-[0_40px_80px_-40px_oklch(0_0_0/0.55)]"
    >
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <span className="h-2 w-2 rounded-full bg-foreground/15" />
        <span className="h-2 w-2 rounded-full bg-foreground/15" />
        <span className="h-2 w-2 rounded-full bg-foreground/15" />
        <span className="ml-3 truncate text-[12px] text-muted-foreground">
          search?q=restaurant+bejaia+book+a+table
        </span>
      </div>
      <div className="p-5 md:p-7">
        <div className="flex items-center gap-3 rounded-full border border-border px-5 py-3">
          <svg
            viewBox="0 0 24 24"
            className="h-4 w-4 text-muted-foreground"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            aria-hidden
          >
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.5-3.5" />
          </svg>
          <span className="text-[14.5px]">restaurant bejaia book a table</span>
        </div>
        <div className="mt-4 flex gap-5 border-b border-border pb-3 text-[12.5px] text-muted-foreground">
          <span className="border-b-2 border-foreground pb-2.5 -mb-[13px] text-foreground">
            All
          </span>
          <span>Maps</span>
          <span>Images</span>
          <span className="hidden sm:inline">News</span>
        </div>

        <div className="mt-5 space-y-2">
          {order.map((k, idx) => {
            const r = results[k];
            if (!r) return null;
            return (
              <motion.article
                key={r.id}
                layout
                transition={{ layout: { duration: 1.1, ease } }}
                className={`relative px-4 py-4 transition-colors duration-700 ${
                  r.you && ranked ? "bg-primary/[0.06] ring-1 ring-primary/35" : ""
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold ${
                      r.you
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                    aria-hidden
                  >
                    {r.you ? "Y" : r.crumb[0]}
                  </span>
                  <p className="truncate text-[12px] text-muted-foreground">{r.crumb}</p>
                  {r.you && (
                    <motion.span
                      className="eyebrow ml-auto shrink-0 text-primary"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: ranked ? 1 : 0 }}
                      transition={{ duration: 0.6, delay: ranked ? 0.8 : 0 }}
                    >
                      Position {idx + 1}
                    </motion.span>
                  )}
                </div>
                <p
                  className={`mt-1.5 text-[17px] leading-snug ${r.you ? "font-medium text-primary" : "text-foreground/80"}`}
                >
                  {r.title}
                </p>
                <p className="mt-1 text-[13.5px] leading-relaxed text-muted-foreground">{r.text}</p>
                {r.you && (
                  <div className="mt-3 flex flex-wrap gap-2 text-[12px]">
                    {["Menu", "Book a table", "Opening hours", "Location"].map((l) => (
                      <span key={l} className="rounded-full border border-border px-3 py-1">
                        {l}
                      </span>
                    ))}
                  </div>
                )}
              </motion.article>
            );
          })}
        </div>
      </div>
    </div>
  );
}

const vitals = ["Performance", "Accessibility", "Best practices", "SEO"];

function Ring({ label, delay }: { label: string; delay: number }) {
  const C = 2 * Math.PI * 26;
  return (
    <div className="flex flex-col items-start gap-3">
      <div className="relative h-16 w-16">
        <svg viewBox="0 0 60 60" className="h-full w-full -rotate-90" aria-hidden>
          <circle
            cx="30"
            cy="30"
            r="26"
            fill="none"
            stroke="currentColor"
            strokeOpacity="0.14"
            strokeWidth="2"
          />
          <motion.circle
            cx="30"
            cy="30"
            r="26"
            fill="none"
            className="stroke-primary-soft"
            strokeWidth="2"
            strokeDasharray={C}
            initial={{ strokeDashoffset: C }}
            whileInView={{ strokeDashoffset: C * 0.08 }}
            viewport={{ once: true }}
            transition={{ duration: 1.6, ease, delay }}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center font-heading text-[15px] font-medium">
          90+
        </span>
      </div>
      <p className="text-[13px] text-ink-muted">{label}</p>
    </div>
  );
}

function Seo() {
  return (
    <section
      id="seo"
      className="relative overflow-hidden bg-ink py-24 text-ink-foreground md:py-36"
    >
      <div className={`${wrap} grid gap-16 lg:grid-cols-12 lg:gap-10`}>
        <div className="lg:col-span-5">
          <Reveal>
            <Kicker n="02" onDark>
              SEO & Google visibility
            </Kicker>
          </Reveal>
          <Lines className="display mt-8" lines={["Beautiful websites.", "Built to be found."]} />
          <Reveal delay={0.1}>
            <p className="lede mt-7 max-w-[44ch] text-ink-muted">
              We build fast, optimized and SEO-friendly websites designed to help your business
              improve its visibility on Google, reach new customers and compete for top positions in
              search results.
            </p>
          </Reveal>
          <Reveal as="div" delay={0.15} className="mt-12">
            <ul className="grid border-t border-ink-border sm:grid-cols-2 sm:gap-x-8">
              {seoPoints.map((p, i) => (
                <li
                  key={p}
                  className="flex items-baseline gap-3 border-b border-ink-border py-3.5 text-[15px]"
                >
                  <span className="eyebrow w-6 shrink-0 text-primary-soft">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {p}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal className="mt-12 max-w-[42ch]">
            <p className="font-heading text-[1.4rem] font-medium leading-snug tracking-[-0.018em]">
              Your business deserves to be on Google's first page.
            </p>
            <p className="mt-2 text-[15px] text-ink-muted">
              We give your site every technical advantage to compete for it. More visibility. More
              opportunities.
            </p>
          </Reveal>
        </div>

        <div className="lg:col-span-6 lg:col-start-7 lg:pt-20">
          <Reveal>
            <SerpMock />
            <p className="eyebrow mt-4 text-ink-muted">Illustrative search results page</p>
          </Reveal>
          <Reveal delay={0.1} className="mt-14 border-t border-ink-border pt-8">
            <p className="eyebrow text-ink-muted">Lighthouse scores we aim for at launch</p>
            <div className="mt-6 grid grid-cols-2 gap-8 sm:grid-cols-4">
              {vitals.map((v, i) => (
                <Ring key={v} label={v} delay={0.15 * i} />
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Work                                                                */
/* ------------------------------------------------------------------ */

type Project = {
  name: string;
  ind: string;
  svc: string;
  url: string;
  headline: string;
  links: string[];
  img: string;
  w: number;
  h: number;
  cls: string;
  ratio: string;
  brandClass: string;
};

const projects: Project[] = [
  {
    name: "Maison Sable",
    ind: "Restaurant",
    svc: "Website · Online booking",
    url: "maisonsable.dz",
    headline: "Seasonal cuisine, by the sea.",
    links: ["Menu", "Book"],
    img: restaurantImg,
    w: 1280,
    h: 896,
    cls: "md:col-span-7",
    ratio: "aspect-[4/3]",
    brandClass: "tracking-[0.28em] uppercase text-[11px] font-semibold",
  },
  {
    name: "Atlas Wear",
    ind: "Fashion",
    svc: "E-commerce · UI/UX",
    url: "atlaswear.dz",
    headline: "Linen for long summers.",
    links: ["Shop", "Bag (0)"],
    img: fashionImg,
    w: 896,
    h: 1152,
    cls: "md:col-span-5 md:mt-40",
    ratio: "aspect-[4/5]",
    brandClass: "text-[15px] font-semibold tracking-[-0.022em]",
  },
  {
    name: "Azur Habitat",
    ind: "Real estate",
    svc: "Website · Property listings",
    url: "azurhabitat.dz",
    headline: "Homes with a view of the bay.",
    links: ["Listings", "Contact"],
    img: realestateImg,
    w: 1280,
    h: 896,
    cls: "md:col-span-9 md:col-start-4",
    ratio: "aspect-[16/10]",
    brandClass: "text-[13px] font-medium uppercase tracking-[0.18em]",
  },
];

function ProjectCard({ p, i }: { p: Project; i: number }) {
  return (
    <Reveal className={p.cls}>
      <a
        href="#contact"
        className="group block"
        aria-label={`${p.name} — ${p.ind} concept. Start a similar project`}
      >
        <div className="border border-border bg-card transition-colors duration-500 group-hover:border-foreground/30">
          {/* browser chrome */}
          <div className="flex items-center gap-3 border-b border-border px-3.5 py-2.5">
            <span className="flex gap-1.5" aria-hidden>
              <span className="h-[7px] w-[7px] rounded-full bg-foreground/15" />
              <span className="h-[7px] w-[7px] rounded-full bg-foreground/15" />
              <span className="h-[7px] w-[7px] rounded-full bg-foreground/15" />
            </span>
            <span className="mx-auto truncate text-[11.5px] text-muted-foreground">{p.url}</span>
            <span className="eyebrow text-[10px] text-muted-foreground">Concept</span>
          </div>
          {/* viewport */}
          <div className={`relative overflow-hidden ${p.ratio}`}>
            <img
              src={p.img}
              alt={`${p.name} concept website — ${p.ind.toLowerCase()} homepage`}
              width={p.w}
              height={p.h}
              loading="lazy"
              decoding="async"
              className="h-full w-full object-cover transition-transform duration-[1400ms] ease-[var(--ease-studio)] group-hover:scale-[1.035]"
            />
            <div
              className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/55"
              aria-hidden
            />
            <div className="absolute inset-x-0 top-0 flex items-center justify-between px-5 py-4 text-white md:px-7 md:py-5">
              <span className={`font-heading ${p.brandClass}`}>{p.name}</span>
              <span className="flex gap-4 text-[11px] font-medium opacity-90">
                {p.links.map((l) => (
                  <span key={l}>{l}</span>
                ))}
              </span>
            </div>
            <p className="absolute bottom-5 left-5 max-w-[16ch] font-heading text-[clamp(1.4rem,2.8vw,2.6rem)] font-medium leading-[1.06] tracking-[-0.026em] text-white md:bottom-7 md:left-7">
              {p.headline}
            </p>
          </div>
        </div>
        <div className="mt-5 grid grid-cols-[2.5rem_1fr_auto] items-baseline gap-x-3">
          <span className="eyebrow text-primary">0{i + 1}</span>
          <div>
            <h3 className="font-heading text-[1.6rem] font-medium tracking-[-0.022em]">{p.name}</h3>
            <p className="mt-1 text-[14.5px] text-muted-foreground">{p.svc}</p>
          </div>
          <span className="flex items-center gap-2 text-[13px] text-muted-foreground transition-colors duration-300 group-hover:text-foreground">
            <span className="hidden sm:inline">Concept · {p.ind}</span>
            <SlideArrow className="h-4 w-4" diagonal />
          </span>
        </div>
      </a>
    </Reveal>
  );
}

function Work() {
  return (
    <section id="work" className="py-24 md:py-36">
      <div className={wrap}>
        <div className="grid gap-8 md:grid-cols-12 md:items-end">
          <div className="md:col-span-7">
            <Reveal>
              <Kicker n="03">Selected work</Kicker>
            </Reveal>
            <Lines className="display mt-8" lines={["Good design", "speaks for itself."]} />
          </div>
          <Reveal delay={0.1} className="md:col-span-4 md:col-start-9">
            <p className="text-muted-foreground">
              Concept projects created by our studio to show how we approach different industries.
            </p>
          </Reveal>
        </div>
        <div className="mt-16 grid gap-x-10 gap-y-20 md:mt-24 md:grid-cols-12 md:gap-y-28">
          {projects.map((p, i) => (
            <ProjectCard key={p.name} p={p} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Process                                                             */
/* ------------------------------------------------------------------ */

const steps = [
  {
    t: "Discovery",
    d: "We learn about your business, your customers and your goals.",
    out: "Brief & sitemap",
  },
  {
    t: "Design",
    d: "We shape the visual direction and the experience, page by page.",
    out: "Page designs",
  },
  {
    t: "Development",
    d: "We build a fast, responsive and search-friendly website.",
    out: "Working website",
  },
  {
    t: "Launch & indexing",
    d: "We test, publish and prepare your site to be indexed by Google.",
    out: "Live & indexed",
  },
];

function StepGlyph({ i }: { i: number }) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.25,
    strokeLinecap: "round" as const,
  };
  return (
    <svg viewBox="0 0 64 64" className="h-14 w-14 text-foreground/70" aria-hidden>
      {i === 0 && (
        <g {...common}>
          <circle cx="26" cy="26" r="14" />
          <path d="m36 36 14 14" />
          <path d="M20 22h12M20 28h8" />
        </g>
      )}
      {i === 1 && (
        <g {...common}>
          <rect x="10" y="12" width="44" height="40" />
          <path d="M10 22h44M24 22v30" />
          <rect x="30" y="28" width="18" height="10" />
          <path d="M30 44h14" />
        </g>
      )}
      {i === 2 && (
        <g {...common}>
          <path d="m22 20-12 12 12 12M42 20l12 12-12 12M36 14l-8 36" />
        </g>
      )}
      {i === 3 && (
        <g {...common}>
          <path d="M12 52h40" />
          <path d="M18 52V40M28 52V32M38 52V24M48 52V14" />
          <path d="m42 14 6-4 4 6" />
        </g>
      )}
    </svg>
  );
}

function Process() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 80%", "end 60%"] });
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.4 });

  return (
    <section id="process" className="border-t border-border bg-card py-24 md:py-36">
      <div className={wrap}>
        <div className="grid gap-8 md:grid-cols-12 md:items-end">
          <div className="md:col-span-8">
            <Reveal>
              <Kicker n="04">How we work</Kicker>
            </Reveal>
            <Lines
              className="display mt-8"
              lines={["A clear process,", "from first call to launch."]}
            />
          </div>
          <Reveal delay={0.1} className="md:col-span-3 md:col-start-10">
            <p className="text-muted-foreground">
              Four steps. One point of contact. No surprises along the way.
            </p>
          </Reveal>
        </div>

        <div ref={ref} className="relative mt-16 md:mt-24">
          {/* progress rail */}
          <div
            className="absolute left-0 top-0 hidden h-px w-full bg-border md:block"
            aria-hidden
          />
          <motion.div
            className="absolute left-0 top-0 hidden h-px w-full origin-left bg-primary md:block"
            style={{ scaleX: progress }}
            aria-hidden
          />
          <div
            className="absolute bottom-0 left-[7px] top-0 w-px bg-border md:hidden"
            aria-hidden
          />
          <motion.div
            className="absolute bottom-0 left-[7px] top-0 w-px origin-top bg-primary md:hidden"
            style={{ scaleY: progress }}
            aria-hidden
          />

          <ol className="grid gap-12 md:grid-cols-4 md:gap-8">
            {steps.map((s, i) => (
              <Reveal
                as="li"
                key={s.t}
                delay={i * 0.08}
                className="relative pl-10 md:pl-0 md:pt-10"
              >
                <span
                  className="absolute left-0 top-1.5 h-[15px] w-[15px] border border-primary bg-card md:-top-[7px]"
                  aria-hidden
                />
                <div className="flex items-start justify-between">
                  <span className="font-heading text-[clamp(3rem,5vw,4.5rem)] font-medium leading-none tracking-[-0.045em] text-foreground/15">
                    0{i + 1}
                  </span>
                  <StepGlyph i={i} />
                </div>
                <h3 className="title mt-8">{s.t}</h3>
                <p className="mt-3 max-w-[30ch] text-[15.5px] text-muted-foreground">{s.d}</p>
                <p className="eyebrow mt-6 flex items-center gap-2 text-foreground/80">
                  <span className="text-primary">→</span> {s.out}
                </p>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* About                                                               */
/* ------------------------------------------------------------------ */

function About() {
  const values = [
    {
      t: "A site that represents you",
      d: "A professional image that builds trust from the first visit.",
    },
    { t: "Visibility on Google", d: "Solid technical foundations so customers can find you." },
    {
      t: "Direct collaboration",
      d: "You work directly with the people designing and building your site.",
    },
  ];
  const facts = [
    { k: "Based in", v: "Béjaïa, Algérie" },
    { k: "Working with", v: "Businesses in Algeria and beyond" },
    { k: "Disciplines", v: "Design, development & SEO" },
  ];
  return (
    <section id="about" className="py-24 md:py-36">
      <div className={wrap}>
        <Reveal>
          <Kicker n="05">About</Kicker>
        </Reveal>
        <ScrollWords
          className="mt-10 max-w-[24ch] font-heading text-[clamp(2rem,4.6vw,4.4rem)] font-medium leading-[1.08] tracking-[-0.034em]"
          text="We design websites the way an architect plans a building: light, structure, and a clear way through."
        />

        <div className="mt-20 grid gap-14 md:mt-28 md:grid-cols-12 md:gap-10">
          <figure className="md:col-span-5">
            <RevealImage
              src={bejaiaImg}
              alt="Béjaïa at dusk: the city lights, the harbour and the bay, with the mountains behind"
              width={900}
              height={1350}
              parallax={5}
              sizes="(min-width: 768px) 40vw, 100vw"
              className="aspect-[4/5]"
            />
            <figcaption className="eyebrow mt-4 flex justify-between text-muted-foreground">
              <span>Fig. 07</span>
              <span className="normal-case tracking-normal text-[13px]">
                Béjaïa and its bay — where the studio is based.
              </span>
            </figcaption>
          </figure>

          <div className="md:col-span-6 md:col-start-7 md:pt-8">
            <Lines
              as="h2"
              className="font-heading text-[clamp(1.75rem,2.6vw,2.4rem)] font-medium leading-[1.12] tracking-[-0.026em]"
              lines={["An independent studio,", "focused on results."]}
            />
            <Reveal delay={0.1}>
              <p className="lede mt-6 text-muted-foreground">
                NEXORIA is a digital studio based in Béjaïa, Algeria. We help businesses build a
                professional online presence through thoughtful design, modern development and
                attention to detail.
              </p>
            </Reveal>

            <ol className="mt-12 border-b border-border">
              {values.map((v, i) => (
                <Reveal
                  as="li"
                  key={v.t}
                  delay={i * 0.06}
                  className="grid grid-cols-[2.5rem_1fr] gap-x-3 border-t border-border py-6"
                >
                  <span className="eyebrow pt-1.5 text-primary">0{i + 1}</span>
                  <div>
                    <h3 className="font-heading text-[1.25rem] font-medium tracking-[-0.015em]">
                      {v.t}
                    </h3>
                    <p className="mt-1.5 text-muted-foreground">{v.d}</p>
                  </div>
                </Reveal>
              ))}
            </ol>

            <Reveal as="div" className="mt-12">
              <dl className="grid gap-6 sm:grid-cols-3">
                {facts.map((f) => (
                  <div key={f.k}>
                    <dt className="eyebrow text-muted-foreground">{f.k}</dt>
                    <dd className="mt-2 text-[15px] font-medium leading-snug">{f.v}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Contact                                                             */
/* ------------------------------------------------------------------ */

const projectTypes = ["Website", "E-commerce", "SEO", "Redesign"];

function ContactForm() {
  const [types, setTypes] = useState<string[]>(["Website"]);
  const [name, setName] = useState("");
  const [business, setBusiness] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);

  const toggle = (t: string) =>
    setTypes((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) {
      setError("Please add your name and a few words about your project.");
      return;
    }
    setError(null);
    const subject = `New project — ${types.length ? types.join(", ") : "Website"}`;
    const body = [
      `Name: ${name.trim()}`,
      ...(business.trim() ? [`Business: ${business.trim()}`] : []),
      `Interested in: ${types.join(", ") || "—"}`,
      "",
      message.trim(),
    ].join("\n");
    window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const field =
    "peer w-full border-0 border-b border-ink-border bg-transparent px-0 pb-3 pt-6 text-[16px] text-ink-foreground outline-none transition-colors duration-300 placeholder:text-transparent focus:border-ink-foreground";
  const label =
    "pointer-events-none absolute left-0 top-6 text-[15px] text-ink-muted transition-all duration-300 peer-focus:top-0 peer-focus:text-[11px] peer-focus:uppercase peer-focus:tracking-[0.12em] peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:uppercase peer-[:not(:placeholder-shown)]:tracking-[0.12em]";

  return (
    <form onSubmit={submit} noValidate className="space-y-8">
      <fieldset>
        <legend className="eyebrow text-ink-muted">I'm interested in</legend>
        <div className="mt-4 flex flex-wrap gap-2">
          {projectTypes.map((t) => {
            const on = types.includes(t);
            return (
              <button
                key={t}
                type="button"
                aria-pressed={on}
                onClick={() => toggle(t)}
                className={`h-10 rounded-full border px-4 text-[14px] transition-colors duration-300 ${
                  on
                    ? "border-ink-foreground bg-ink-foreground text-ink"
                    : "border-ink-border text-ink-foreground hover:border-ink-foreground/60"
                }`}
              >
                {t}
              </button>
            );
          })}
        </div>
      </fieldset>
      <div className="grid gap-8 sm:grid-cols-2">
        <div className="relative">
          <input
            id="c-name"
            className={field}
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
            required
          />
          <label htmlFor="c-name" className={label}>
            Your name
          </label>
        </div>
        <div className="relative">
          <input
            id="c-biz"
            className={field}
            placeholder="Business"
            value={business}
            onChange={(e) => setBusiness(e.target.value)}
            autoComplete="organization"
          />
          <label htmlFor="c-biz" className={label}>
            Business (optional)
          </label>
        </div>
      </div>
      <div className="relative">
        <textarea
          id="c-msg"
          rows={3}
          className={`${field} resize-none`}
          placeholder="Message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
        />
        <label htmlFor="c-msg" className={label}>
          Tell us about your project
        </label>
      </div>
      {error && (
        <p role="alert" className="text-[14px] text-primary-soft">
          {error}
        </p>
      )}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
        <Button type="submit" variant="light">
          Send the brief
        </Button>
        <p className="text-[13px] text-ink-muted">Opens your email app, addressed to {EMAIL}.</p>
      </div>
    </form>
  );
}

function Contact() {
  return (
    <section id="contact" className="bg-ink text-ink-foreground">
      <div className="relative h-[46vh] min-h-[320px] overflow-hidden md:h-[62vh]">
        <RevealImage
          src={lightImg}
          alt="Late sunlight cutting a diagonal across a concrete wall"
          width={1600}
          height={1067}
          parallax={8}
          sizes="100vw"
          className="absolute inset-0 h-full w-full"
        />
        <div
          className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink/10 via-ink/20 to-ink"
          aria-hidden
        />
        <div className={`${wrap} absolute inset-x-0 bottom-0 pb-10 md:pb-14`}>
          <Reveal>
            <Kicker n="06" onDark>
              Let's talk
            </Kicker>
          </Reveal>
          <Lines
            className="mt-6 font-heading text-[clamp(2.6rem,7vw,7rem)] font-medium leading-[1] tracking-[-0.038em]"
            lines={["Ready to be found", "by more customers?"]}
          />
        </div>
      </div>

      <div className={`${wrap} grid gap-16 py-20 md:grid-cols-12 md:py-28`}>
        <div className="md:col-span-5">
          <Reveal>
            <p className="lede max-w-[36ch] text-ink-muted">
              Tell us about your business. We'll reply with ideas and a clear proposal.
            </p>
            <a
              href={`mailto:${EMAIL}`}
              className="group mt-10 inline-block max-w-full font-heading text-[clamp(1.5rem,2.6vw,2.25rem)] font-medium leading-[1.15] tracking-[-0.026em]"
            >
              <span className="link-draw pb-1 group-hover:[background-size:100%_1px]">
                {EMAIL.split("@")[0]}
              </span>
              <wbr />
              <span className="whitespace-nowrap">
                <span className="link-draw pb-1 group-hover:[background-size:100%_1px]">
                  @{EMAIL.split("@")[1]}
                </span>
                <SlideArrow className="ml-3 h-6 w-6 align-[-0.1em] text-primary-soft" diagonal />
              </span>
            </a>
          </Reveal>
          <Reveal delay={0.1} className="mt-14 border-t border-ink-border pt-8">
            <div>
              <p className="eyebrow text-ink-muted">Studio</p>
              <p className="mt-2 text-[15px]">Béjaïa, Algérie</p>
            </div>
          </Reveal>
        </div>
        <Reveal delay={0.1} className="md:col-span-6 md:col-start-7">
          <ContactForm />
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Footer                                                              */
/* ------------------------------------------------------------------ */

function Footer() {
  const time = useStudioTime();
  return (
    <footer className="overflow-hidden bg-background">
      <div className={`${wrap} grid gap-12 pb-10 pt-20 md:grid-cols-12`}>
        <div className="md:col-span-5">
          <Logo />
          <p className="mt-5 max-w-xs text-muted-foreground">
            Beautiful websites, built to be found.
          </p>
        </div>
        <div className="md:col-span-2">
          <p className="eyebrow text-muted-foreground">Navigation</p>
          <ul className="mt-5 space-y-2">
            {navItems.map((n) => (
              <li key={n.label}>
                <a href={n.href} className="link-draw">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div className="md:col-span-3">
          <p className="eyebrow text-muted-foreground">Contact</p>
          <ul className="mt-5 space-y-2">
            <li>
              <a href={`mailto:${EMAIL}`} className="link-draw">
                {EMAIL}
              </a>
            </li>
            <li className="text-muted-foreground">Béjaïa, Algérie · {time ?? "--:--"}</li>
          </ul>
        </div>
        <div className="md:col-span-2">
          <p className="eyebrow text-muted-foreground">Social</p>
          <ul className="mt-5 space-y-2">
            {["Instagram", "LinkedIn", "Behance"].map((s) => (
              <li key={s}>
                <a href="#" className="link-draw">
                  {s}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className={`${wrap} @container`}>
        <p
          className="select-none font-heading text-[22.5cqw] font-medium leading-[0.78] tracking-[-0.048em] text-foreground"
          aria-hidden
        >
          NEXORIA<span className="text-primary">.</span>
        </p>
      </div>
      <div
        className={`${wrap} mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-border py-6 text-[13px] text-muted-foreground`}
      >
        <p>© 2026 NEXORIA. All rights reserved.</p>
        <a href="#home" className="group inline-flex items-center gap-2">
          <span className="link-draw">Back to top</span>
          <svg
            viewBox="0 0 24 24"
            className="h-3.5 w-3.5 transition-transform duration-500 group-hover:-translate-y-0.5"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            aria-hidden
          >
            <path d="M12 19V5M6 11l6-6 6 6" />
          </svg>
        </a>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <MotionConfig reducedMotion="user">
      <main className="min-h-screen bg-background text-foreground">
        <Nav />
        <Hero />
        <Services />
        <Seo />
        <Work />
        <Process />
        <About />
        <Contact />
        <Footer />
      </main>
    </MotionConfig>
  );
}
