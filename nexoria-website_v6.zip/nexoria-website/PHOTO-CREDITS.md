# Photo credits

New photographs come from Unsplash (Unsplash License — free for commercial use, no attribution required; credited here as good practice).

| File | Photographer | Source |
|---|---|---|
| `src/assets/hero-arcade.webp` | Roman Kravtsov | https://unsplash.com/photos/Nja16QPdp1A |
| `src/assets/service-code.webp` | Dominik Malinowski | https://unsplash.com/photos/33BNdaQHH9Q |
| `src/assets/service-product.webp` | Tanya Yarosh | https://unsplash.com/photos/ErnAQXPG2ns |
| `src/assets/about-bejaia.webp` | Walid Amghar | https://unsplash.com/photos/8Bw3FnqPmp8 (Béjaïa, Algeria) |
| `src/assets/contact-light.webp` | set.sj | https://unsplash.com/photos/Xmh2Ang3-y4 |

Kept from the previous version (re-encoded to WebP): `studio`, `project-restaurant`, `project-fashion`, `project-realestate`.
Removed: `hero-laptop`, `service-dev`, `service-shop` (posed people at computers).
